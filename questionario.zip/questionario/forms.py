from django.forms import *

from questionario.models import Questionario, Pergunta


# from questionario.models import Questionario, Pergunta, Resposta

class QuestionarioForm(ModelForm):
    class Meta:
        model = Questionario
        exclude = ['id','estadoquestid']
        widgets = {
            'titulo': TextInput(attrs={'class': 'input'}),
        }


class PerguntasForm(ModelForm):
    class Meta:
        model = Pergunta
        exclude = ['id', 'questionarioid']
        widgets = {
            'pergunta': TextInput(attrs={'class': 'input'}),
        }


# class RespostaForm(ModelForm):
#     class Meta:
#         model = Resposta
#         exclude = ['id','perguntaid']
#         widgets = {
#             'resposta': TextInput(attrs={'class': 'input'})
#         }
