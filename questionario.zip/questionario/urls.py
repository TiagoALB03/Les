from django.urls import path
from . import views

app_name = 'questionarios'
urlpatterns = [
    path('questionarioadmin', views.consultar_questionarios.as_view(), name='consultar-questionarios-admin'),

    path('criarQuestionario', views.criarquestionario, name='criar-questionario'),
    path('arquivarQuestionario/<int:questionario_id>', views.configurarQuestionario, name='arquivar-questionario'),
    path('criarPerguntas/<int:questionario_id>', views.criarperguntas, name='criar-perguntas'),

    # #ajax ----------
    path('ajax/addPergRow', views.newPergRow, name='ajaxAddPergRow'),
    # path('ajax/addResRow', views.newResRow, name='ajaxAddResRow'),
]