import django_filters
from django.db.models import Exists, OuterRef
from questionario.models import *

class QuestionarioFilter(django_filters.FilterSet):
    ano = django_filters.CharFilter(field_name='ano', lookup_expr='icontains')

    class Meta:
        model = Questionario
        fields = '__all__'