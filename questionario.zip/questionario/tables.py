import django_tables2 as django_tables
from utilizadores.models import Administrador
from questionario.models import Questionario
from django.utils.html import format_html
from django.urls import reverse


class QuestionarioTable(django_tables.Table):
    titulo = django_tables.Column('titulo')
    ano = django_tables.Column(accessor='getQuestionarioDateID')
    estado = django_tables.Column(accessor='getQuestionarioEstado', attrs={"th": {"width": "130"}})
    acoes = django_tables.Column('Ações', empty_values=(),
                                 orderable=False, attrs={"th": {"width": "150"}})

    class Meta:
        model = Questionario
        sequence = ('titulo', 'ano', 'estado', 'acoes')

    def before_render(self, request):
        self.columns.hide('id')
        self.columns.hide('dateid')
        self.columns.hide('estadoquestid')

    def render_estado(self, record):
        if (record.getQuestionarioEstado == 'pendente'):
            estado = "Pendente"
            cor = "is-warning"
        elif (record.getQuestionarioEstado == 'valido'):
            estado = "Valido"
            cor = "is-success"
        elif (record.getQuestionarioEstado == 'arquivado'):
            estado = "Arquivado"
            cor = "is-secondary"
        elif (record.getQuestionarioEstado == 'publicado'):
            estado = "Publicado"
            cor = "is-info"
        elif (record.getQuestionarioEstado == 'concluido'):
            estado = "Concluido"
            cor = "is-primary"
        return format_html(f"""
                <span class="tag {cor}" style="font-size: small; min-width: 110px;">
                    {estado}
                </span>
                """)

    def render_acoes(self, record):
        primeiro_botao =  """<span class="icon"></span>"""
        if record.getQuestionarioEstado == "concluido":
            primeiro_botao = f"""
                           <a data-tooltip="Arquivar" href="{reverse('questionarios:arquivar-questionario', args=[record.getQuestionarioID])}">
                               <span class="icon">
                                   <i class="fas fa-archive" aria-hidden="true" style="color: #F4B400"></i>
                               </span>
                           </a>
                           """
        return format_html(f"""
        <div>
            {primeiro_botao}
        </div>
        """)
