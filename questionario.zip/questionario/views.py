from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.urls import reverse

from configuracao.forms import TemaForm
from utilizadores.views import user_check
from .filters import QuestionarioFilter
from .forms import *
from .models import *
from utilizadores.models import *
from inscricoes.models import Inscricao, Inscricaosessao, Inscricaotransporte
from atividades.models import Tema
from datetime import datetime, timezone, date, time
from _datetime import timedelta
from utilizadores.views import user_check
from configuracao.tables import CursoTable, DepartamentoTable, DiaAbertoTable, EdificioTable, MenuTable, TemaTable, \
    TransporteTable, UOTable
from django_tables2 import SingleTableMixin, SingleTableView
from django_filters.views import FilterView
from configuracao.filters import CursoFilter, DepartamentoFilter, DiaAbertoFilter, EdificioFilter, MenuFilter, \
    TemaFilter, TransporteFilter, UOFilter
from .tables import QuestionarioTable


# Create your views here.
class consultar_questionarios(SingleTableMixin, FilterView):
    table_class = QuestionarioTable
    template_name = 'questionario/questionarioAdmin.html'
    filterset_class = QuestionarioFilter
    table_pagination = {
        'per_page': 10
    }

    def dispatch(self, request, *args, **kwargs):
        user_check_var = user_check(
            request=request, user_profile=[Administrador])
        if not user_check_var.get('exists'):
            return user_check_var.get('render')
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(SingleTableMixin, self).get_context_data(**kwargs)
        table = self.get_table(**self.get_table_kwargs())
        table.request = self.request
        table.fixed = True
        context[self.get_context_table_name(table)] = table
        return context


def criarquestionario(request):
    user_check_var = user_check(request=request, user_profile=[Administrador])
    if user_check_var.get('exists') == False:
        return user_check_var.get('render')

    questionario = Questionario()
    questionarioForm = QuestionarioForm(instance=questionario)

    if request.method == 'POST':
        questionarioForm = QuestionarioForm(request.POST, request.FILES)
        if questionarioForm.is_valid():
            questionario = questionarioForm.save(commit=False)
            questionario.estadoquestid = EstadosQuest.objects.get(id=2)
            questionario.save()

            return redirect('questionarios:criar-perguntas', questionario_id=questionario.id)

    return render(request=request,
                  template_name='questionario/criarQuestionario.html',
                  context={'form': questionarioForm})


def configurarQuestionario(request, questionario_id):
    user_check_var = user_check(request=request, user_profile=[Administrador])
    if user_check_var.get('exists') == False:
        return user_check_var.get('render')

    questionarioFormSet = modelformset_factory(model=Questionario, exclude=['id'], widgets={
        'titulo': TextInput(attrs={'class': 'input'}),
        'dateid': Select(attrs={'class': 'input'}),
        'estadoquestid': Select(attrs={'class': 'input'}),
    }, extra=0, min_num=1, can_delete=True)
    questionarioForms = questionarioFormSet(queryset=Questionario.objects.none())
    questionario = Questionario()

    if questionario_id is not None:
        questionario = Questionario.objects.get(id=questionario_id)
        questionarioForms = questionarioFormSet(queryset=Questionario.objects.filter(id=questionario.id))
        allowMore, allowDelete = False, False

    if (request.method == 'POST'):
        questionarioForms = questionarioFormSet(request.POST)
        if questionarioForms.is_valid():
            questionarioForms.save()
            return redirect('questionarios:consultar-questionarios-admin')

    return render(request=request,
                  template_name='questionario/arquivarQuestionario.html',
                  context={'form': questionarioForms,
                           'allowMore': allowMore,
                           'allowDelete': allowDelete,
                           })


def criarperguntas(request, questionario_id):
    user_check_var = user_check(request=request, user_profile=[Administrador])
    if user_check_var.get('exists') == False:
        return user_check_var.get('render')
    questionario = Questionario(id=questionario_id)

    perguntaFormSet = modelformset_factory(model=Pergunta, exclude=['id', 'questionarioid'],
                                           widgets={
                                               'pergunta': TextInput(attrs={'class': 'input'}),
                                               'temaid': Select(attrs={'class': 'input'}),
                                               'tiporespostaid': Select(attrs={'class': 'input'}),
                                           }, extra=0, min_num=1, max_num=1000, can_delete=True)
    pergunta_form_set = perguntaFormSet(queryset=Pergunta.objects.none())
    pergunta = Pergunta()
    allowMore = True
    allowDelete = True

    if request.method == 'POST':
        pergunta_form_set = perguntaFormSet(request.POST, request.FILES)
        if pergunta_form_set.is_valid():
            objectPerg = pergunta_form_set.save(commit=False)
            for obj in objectPerg:
                obj.questionarioid = questionario
                obj.save()

            return redirect('questionarios:consultar-questionarios-admin')

    return render(request=request,
                  template_name='questionario/criarPerguntas.html',
                  context={'form': pergunta_form_set,
                           'allowMore': allowMore,
                           'allowDelete': allowDelete})

    # user_check_var = user_check(request=request, user_profile=[Administrador])
    # if user_check_var.get('exists') == False:
    #     return user_check_var.get('render')
    # questionario = Questionario(id=questionario_id)
    # # tema = Tema()
    # perguntaFormSet = modelformset_factory(model=Pergunta, exclude=['id','questionarioid'],
    #                                        widgets={
    #                                            'pergunta': TextInput(attrs={'class': 'input'}),
    #                                            'temaid': Select(attrs={'class': 'input'}),
    #                                            'tiporespostaid': Select(attrs={'class': 'input'}),
    #                                        }, extra=0, min_num=1, max_num=1000, can_delete=True)
    # pergunta_form_set = perguntaFormSet(queryset=Pergunta.objects.none())
    # # pergunta = Pergunta()
    # # perguntaForm = PerguntasForm(instance=pergunta)
    # if request.method == 'POST':
    #     # perguntaForm = PerguntasForm(request.POST, request.FILES)
    #     pergunta_form_set = perguntaFormSet(request.POST)
    #     if pergunta_form_set.is_valid():
    #         instaces = pergunta_form_set.save(commit=False)
    #         tema = Tema()
    #         for instace in instaces:
    #             instace.questionarioid = questionario
    #             instace.save()
    #         for instace in pergunta_form_set.deleted_objects:
    #             instace.delete()
    #
    #         return redirect('questionarios:consultar-questionarios-admin')
    #
    # return render(request=request,
    #               template_name='questionario/criarPerguntas.html',
    #               context={'form': pergunta_form_set})

    # perguntas = Pergunta.objects.filter(questionarioid=id)
    # respostaFormSet = modelformset_factory(model=Resposta, form=RespostaForm, extra=0, min_num=1, can_delete=True)
    # formSet2 = respostaFormSet(queryset=Pergunta.objects.none())
    # if request.method == 'POST':
    #     # formSet2 = respostaFormSet(request.POST, queryset=Resposta.objects.none())
    #     for pergunta in perguntas:
    #         formSet2 = RespostaForm(request.POST)
    #         if formSet2.is_valid():
    #             instances = formSet2.save(commit=False)
    #             # for instance in instances:
    #             pergunta_id = pergunta
    #             Resposta.objects.create(perguntaid=pergunta_id, resposta=instances.resposta)
    #     return redirect('questionarios:consultar-questionarios-admin')
    # else:
    #     formSet = RespostaForm()
    # return render(request=request, template_name='questionario/criarRespostas.html',
    #               context={'perguntas': perguntas, 'formset': formSet})


def newPergRow(request):
    value = int(request.POST.get('extra'))
    data = {
        'form_pergunta': "form-" + str(value - 1) + "-pergunta",
        'form_tiporespostid': "form-" + str(value - 1) + "-tiporespostaid",
        'form_temaid': "form-" + str(value - 1) + "-temaid",
        'form_id': 'form-' + str(value - 1) + '-id',
        'tipos': TipoResposta.objects.all(),
        'options': TemaPerg.objects.all(),
    }
    return render(request=request, template_name='questionario/questionarioPerguntasRow.html', context=data)


def arquivarquestionario(request, questionario_id):
    user_check_var = user_check(request=request, user_profile=[Administrador])
    if user_check_var.get('exists') == False:
        return user_check_var.get('render')
    questionario = Questionario(id=questionario_id)
    questionario.estadoquestid = EstadosQuest.objects.get(id=1)
    questionario.save()
    return render(request=request,
                  template_name='questionario/arquivarQuestionario.html',
                  context={'quest': questionario})
