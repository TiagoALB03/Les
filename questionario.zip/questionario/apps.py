from django.apps import AppConfig


class QuestionarioConfig(AppConfig):
    name = 'questionario'
